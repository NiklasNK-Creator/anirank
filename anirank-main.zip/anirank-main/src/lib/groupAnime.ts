import { JikanAnime } from "./jikan";

/**
 * Normalize an anime title to a base franchise name
 * so that e.g. "Frieren Season 2" and "Frieren" group together.
 */
function normalizeTitle(anime: JikanAnime): string {
  const title = (anime.title_english || anime.title).toLowerCase();

  return title
    // Remove common sequel/season indicators
    .replace(/\s*(season|part|cour)\s*\d+/gi, "")
    .replace(/\s*\d+(st|nd|rd|th)\s*(season|cour|part)/gi, "")
    .replace(/\s*(ii|iii|iv|v|vi)(\s|$)/gi, " ")
    .replace(/\s*:\s*(part|season)\s*\w+/gi, "")
    .replace(/\s*-\s*(part|season)\s*\w+/gi, "")
    // Remove trailing numbers that look like season numbers (e.g. "Title 2")
    .replace(/\s+\d+\s*$/, "")
    // Remove special suffixes
    .replace(/\s*(final|the final|continuation|kanketsu-hen|recap|prologue|epilogue)\s*/gi, "")
    // Clean up
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export interface GroupedAnime {
  key: string;
  main: JikanAnime;
  seasons: JikanAnime[];
  totalEpisodes: number;
  bestScore: number | null;
}

/**
 * Group an array of anime by franchise.
 * Returns the highest-scored entry as the "main" representative.
 */
export function groupAnimeByFranchise(animeList: JikanAnime[]): GroupedAnime[] {
  const groups = new Map<string, JikanAnime[]>();

  for (const anime of animeList) {
    // Only group TV series and movies, not specials/OVAs
    const key = normalizeTitle(anime);
    if (!groups.has(key)) {
      groups.set(key, []);
    }
    groups.get(key)!.push(anime);
  }

  const result: GroupedAnime[] = [];

  for (const [key, seasons] of groups) {
    // Sort by score descending, pick highest as representative
    const sorted = [...seasons].sort((a, b) => (b.score ?? 0) - (a.score ?? 0));
    const main = sorted[0];
    const totalEpisodes = seasons.reduce((sum, s) => sum + (s.episodes ?? 0), 0);
    const bestScore = sorted[0].score;

    result.push({ key, main, seasons, totalEpisodes, bestScore });
  }

  // Preserve original order based on first appearance
  return result;
}
